package com.example.btmessenger

import android.os.Bundle
import android.view.Menu
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.btmessenger.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val mLogShown = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DataBindingUtil.setContentView<ActivityMainBinding>(this, R.layout.activity_main)
        //
//        if (savedInstanceState == null) {
//            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//            BluetoothChatFragment fragment = new BluetoothChatFragment();
//            transaction.replace(R.id.sample_content_fragment, fragment);
//            transaction.commit();
//        }
    }

    //
    //    @Override
    //    public boolean onPrepareOptionsMenu(Menu menu) {
    ////        MenuItem logToggle = menu.findItem(R.id.menu_toggle_log);
    ////        logToggle.setVisible(findViewById(R.id.sample_output) instanceof ViewAnimator);
    ////        logToggle.setTitle(mLogShown ? R.string.sample_hide_log : R.string.sample_show_log);
    //
    //        return super.onPrepareOptionsMenu(menu);
    //    }
    //
    //    @Override
    //    public boolean onOptionsItemSelected(MenuItem item) {
    //        switch(item.getItemId()) {
    //            case R.id.menu_toggle_log:
    //                mLogShown = !mLogShown;
    //                ViewAnimator output = (ViewAnimator) findViewById(R.id.sample_output);
    //                if (mLogShown) {
    //                    output.setDisplayedChild(1);
    //                } else {
    //                    output.setDisplayedChild(0);
    //                }
    //                supportInvalidateOptionsMenu();
    //                return true;
    //        }
    //        return super.onOptionsItemSelected(item);
    //    }
}